import { tool_tip } from './tool_tip.js'

const otx_sections = {
  0 : "/general",
  1 : "/geo",
  2 : "/malware",
  3 : "/url_list",
  4 : "/passive_dns" ,
  5 : "/whois" ,
  6 : "/http_scans" };

export let lookup_apik_alienvault_ip = async (ip, api_key) => { //value is vendor res is object with vendor and api key

	const url = "https://otx.alienvault.com/api/v1/indicators/IPv4/" + ip + "/general"
	const myHeaders = new Headers({'X-OTX-API-KEY': api_key}); //is api key
	const myRequest = new Request(url, {method: 'GET', headers: myHeaders})

	let response = await fetch(myRequest).catch((error) => tool_tip([error.message, "error in API comm lookup_apik_vt"], tab) ); //does not catch api auth errors
	const y = await response.json();

	return format_response_alienvault_ip(y,ip);

}

let format_response_alienvault_ip = async (data, ip) => {
	//console.log("alien", data)
	const output = {}
	output['intel_source'] = "AlienVaultOTX";
	output['response_body'] = {};

	try { 
		output['lookup_type'] = data.type;
		output['link'] = "https://otx.alienvault.com/indicator/ip/" + ip;
		output['status_code'] = "200";
		output['lookup_result'] = "Success"

	for (let [key, value] of Object.entries(data)) { 
		if (typeof value !== "object") { output['response_body'][key] = value; } }

	if (data.pulse_info.count !== 0) {
	for (let [key, value] of Object.entries(data.pulse_info.pulses[0].tags)) {
		output['response_body'][`sample pulse info - tag ${key}`] = value; } 
	for (let [key, value] of Object.entries(data.pulse_info.pulses[0])) 
	{
		if (typeof value !== "object") {output['response_body'][`sample pulse info - ${key}`] = value; } 
	} 
	}

	}
	catch(err) {
		output['link'] = "https://otx.alienvault.com/indicator/ip/" + ip;
		output['lookup_result'] = "Failed";
		output['response_body']['error parsing API response'] = err.message;
		output['response_body']['API response'] = data.detail;
	}
		return output;
}

export let lookup_apik_alienvault_domain = async (domain, api_key) => { //value is vendor res is object with vendor and api key

	const url = "https://otx.alienvault.com/api/v1/indicators/domain/" + domain + "/general"
	const myHeaders = new Headers({'X-OTX-API-KEY': api_key}); //is api key
	const myRequest = new Request(url, {method: 'GET', headers: myHeaders})

	let response = await fetch(myRequest).catch((error) => tool_tip([error.message, "error in API comm lookup_apik_vt"], tab) ); //does not catch api auth errors
	const y = await response.json();
	console.log("alien", y);

	return format_response_alienvault_domain(y,domain);

}

let format_response_alienvault_domain = async (data, domain) => {
	//console.log("alien", data)
	const output = {}
	output['intel_source'] = "AlienVaultOTX";
	output['response_body'] = {};

	try { 
		output['lookup_type'] = data.type;
		output['link'] = "https://otx.alienvault.com/indicator/domain/" + domain;
		output['status_code'] = "200";
		output['lookup_result'] = "Success"

	for (let [key, value] of Object.entries(data)) { 
		if (typeof value !== "object") { output['response_body'][key] = value; } }

	if (data.pulse_info.count !== 0) {
	for (let [key, value] of Object.entries(data.pulse_info.pulses[0].tags)) {
		output['response_body'][`sample pulse info - tag ${key}`] = value; }
	for (let [key, value] of Object.entries(data.pulse_info.pulses[0])) 
	{
		if (typeof value !== "object") {output['response_body'][`sample pulse info - ${key}`] = value; } 
	} 
	}
	
	}
	catch(err) {
		output['link'] = "https://otx.alienvault.com/indicator/domain/" + domain;
		output['lookup_result'] = "Failed";
		output['response_body']['error parsing API response'] = err.message;
		output['response_body']['API response'] = data.detail;
	}
		return output;
}

export let lookup_apik_alienvault_hash = async (hash, api_key) => { //value is vendor res is object with vendor and api key

	const url = "https://otx.alienvault.com/api/v1/indicators/file/" + hash + "/general"
	const myHeaders = new Headers({'X-OTX-API-KEY': api_key}); //is api key
	const myRequest = new Request(url, {method: 'GET', headers: myHeaders})

	let response = await fetch(myRequest).catch((error) => tool_tip([error.message, "error in API comm lookup_apik_vt"], tab) ); //does not catch api auth errors
	const y = await response.json();

	return format_response_alienvault_hash(y,hash);

}

let format_response_alienvault_hash = async (data, hash) => {
	//console.log("alien", data)
	const output = {}
	output['intel_source'] = "AlienVaultOTX";
	output['response_body'] = {};

	try { 
		output['lookup_type'] = data.type;
		output['link'] = "https://otx.alienvault.com/indicator/file/" + hash;
		output['status_code'] = "200";
		output['lookup_result'] = "Success"

	for (let [key, value] of Object.entries(data)) { 
		if (typeof value !== "object") { output['response_body'][key] = value; } }

	if (data.pulse_info.count !== 0) {
	for (let [key, value] of Object.entries(data.pulse_info.pulses[0].tags)) {
		output['response_body'][`sample pulse info - tag ${key}`] = value; }
	for (let [key, value] of Object.entries(data.pulse_info.pulses[0])) 
	{
		if (typeof value !== "object") {output['response_body'][`sample pulse info - ${key}`] = value; } 
	} 
	}
	
	}
	catch(err) {
		output['link'] = "https://otx.alienvault.com/indicator/file/" + hash;
		output['lookup_result'] = "Failed";
		output['response_body']['error parsing API response'] = err.message;
		output['response_body']['API response'] = data.detail;
	}
		return output;
}
