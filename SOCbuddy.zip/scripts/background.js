import { context_menu, url_pattern } from './strings.js'
import { validate_ip } from './ip_validate.js'
import { tool_tip, getSelectionText } from './tool_tip.js'
import { quick_ip_check, js_script_lookup } from './quick_ip_check.js'
import { lookup_apik_ip, lookup_apik_domain, lookup_apik_hash } from './lookup_apik.js'


chrome.runtime.onInstalled.addListener(() => {
  for (let [key, value] of Object.entries(context_menu)) {
    chrome.contextMenus.create({
      id: key,
      title: value,
      documentUrlPatterns: url_pattern,
      contexts: ["all"]
    });
  }
});

chrome.contextMenus.onClicked.addListener((item, tab) => {


  const cont_menuid = item.menuItemId
  if (cont_menuid == "send_ext_ip") { //for IP
    var valid_result = validate_ip(item.selectionText); //valid_result is an array ie. ["valid ip", "8.8.8.8"]
    if (valid_result[0] == "valid ip") {
      quick_ip_check(valid_result[1], tab, cont_menuid);
      return;
    }
    else if (valid_result[0] == "invalid ip") {
      tool_tip(valid_result, tab);
      return;
    }
  }

  else if (cont_menuid === "bas") //for others
  {
    js_script_lookup(item.selectionText, tab, cont_menuid);
  }

  else if (cont_menuid.includes("send_ext") === true) //for others
  {
    quick_ip_check(item.selectionText, tab, cont_menuid);
  }


  else if (cont_menuid == "apik_ip"){ //for apikey ip
    var valid_result = validate_ip(item.selectionText); //valid_result is an array ie. ["valid ip", "8.8.8.8"]
    if (valid_result[0] == "valid ip") {
      lookup_apik_ip(valid_result[1], tab); //valid_result[1] is IP address
    }
    else if (valid_result[0] == "invalid ip") {
      console.log("invalid ip - chrome.contextMenus.onClicked.addListener");
      tool_tip(valid_result, tab);
      console.log (tab.id);
      return;
    }
  }

  else if (cont_menuid == "apik_domain"){ //for apikey domain
    lookup_apik_domain(item.selectionText, tab);
  }
  else if (cont_menuid == "apik_hash"){ //for apikey hash
    lookup_apik_hash(item.selectionText, tab);
  }
  else { console.log("feature not found"); }
}
);