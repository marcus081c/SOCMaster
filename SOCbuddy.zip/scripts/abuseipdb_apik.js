import { tool_tip } from './tool_tip.js'

export let lookup_apik_abuseipdb_ip = async (ip, api_key) => { //value is vendor res is object with vendor and api key
	const url = "https://api.abuseipdb.com/api/v2/check" + "?ipAddress=" + ip
	const myHeaders = new Headers({ 'Key': api_key, 'Accept': 'application/json' }); //is api key
	const myRequest = new Request(url , {method: 'GET', headers: myHeaders,});

	let response = await fetch(myRequest).catch((error) => tool_tip([error.message, "error in API comm lookup_apik_vt"], tab) ); //does not catch api auth errors
	const y = await response.json()
	return format_response_abuseipdb(await y, ip)
	
}

export let format_response_abuseipdb = async (data, ip) => {
	const output = {}
	//console.log(data)
	output['intel_source'] = "AbuseIPDB";
	output['response_body'] = {};

	try{ 
	for (let [key, value] of Object.entries(data.data)) { 

	if (typeof value !== "object") { output['response_body'][key] = value; }} //save in output only value that is not an object // output['response_body'][key] = value;
	output['lookup_type'] = "IP address"
	output['link'] = "https://www.abuseipdb.com/check/" + ip
	output['status_code'] = "200";
	output['lookup_result'] = "Success"

	}

	catch(err) {
		output['link'] = "https://www.abuseipdb.com/check/" + ip
		output['lookup_result'] = "Failed"
		output['response_body']['error parsing API response'] = err.message;
		output['response_body']['API response'] = data.errors[0]['detail'];
	}
		return output;
}